function download_backup(file) {
    
    url = domain + '/filemanager/action/' + server_id + '/' + server_id + '/' + file + '/backup-download';
    window.open(url, "_parent");
    
}


function calc(type) {
    if (type == "up") {
        document.getElementById("available").innerHTML = parseInt(document.getElementById("available").innerHTML) - 1;
        document.getElementById("used").innerHTML = parseInt(document.getElementById("used").innerHTML) + 1;
    }
    if (type == "down") {
        document.getElementById("available").innerHTML = parseInt(document.getElementById("available").innerHTML) + 1;
        document.getElementById("used").innerHTML = parseInt(document.getElementById("used").innerHTML) - 1;
    }
}

function create_backup(form){
    
    document.getElementById("create-button-1").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-success disable disabled";
    document.getElementById("create-button-2").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-success disable disabled";
    document.getElementById("create-button-3").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-success disable disabled";
	var submit = form.find("button[type='submit']");
	$.ajax({
	  type: 'POST',
	    url: form.attr("action"),
	    data: form.serialize(),
	    dataType: 'json',
	    success: function(data)
	    {
        if (data.reply == "success") {
            calc('up');
            document.getElementById("create-button-1").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-success";
            document.getElementById("create-button-2").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-success";
            document.getElementById("create-button-3").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-success";

            document.getElementById("message").innerHTML = '<div class="alert alert-success"><strong>Manual backup started! </strong> Please allow up to 10 minutes for the backup to complete. Once complete a page refresh is needed.</div>';
            document.getElementById("buttons").innerHTML = '';
        }
        if (data.reply == "failed") {
            document.getElementById("create-button-1").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-danger";
            document.getElementById("create-button-2").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-danger";
            document.getElementById("create-button-3").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-danger";
            
            document.getElementById("message").innerHTML = '<div class="alert alert-danger"><strong>Backup Failed</strong> You may need to delete old manual backups before creating a new one. Please also check the node is online.</div>';
            document.getElementById("buttons").innerHTML = '';
        }
	}
	});
return false;

} 

function delete_backup(obj) {
    
    $.ajax({
        url: domain + "/server_actions",
        data: {server_id: server_id, secret: secret, action: 'backup-delete', backup: obj.id},
        type: "POST",
        dataType: "json",
        success: function(data){
            
         if (data.reply == "success") {
            calc('down');
            document.getElementById("create-button-1").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-primary";
            document.getElementById("create-button-2").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-primary";
            document.getElementById("create-button-3").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-primary";
            document.getElementById(obj.id + '-main').remove();
            document.getElementById("message").innerHTML = '<div class="alert alert-success"><strong>Backup Deleted!</strong> You may now create a new backup or download previously taken backups. Please refresh to confirm.</div>';
            document.getElementById("buttons").innerHTML = '';
        }
        
        if (data.reply == "failed") {
            document.getElementById("message").innerHTML = '<div class="alert alert-danger"><strong>Backup Delete Failed!</strong> Please check the node is online, refresh and try again.</div>';
            document.getElementById("buttons").innerHTML = '';
        }
            
        }
    });

    return;
    
}
