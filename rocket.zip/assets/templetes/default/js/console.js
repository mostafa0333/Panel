// Password Reset Result
if (reply == "ftp_success") {
    document.getElementById("alerts").innerHTML = '<div class="panel panel-success"><div class="panel-heading"><h3 class="panel-title text-center"><strong>FTP Password Reset: </strong> The FTP password across all nodes has been updated! You can view the password in FTP Details.</h3></div></div><br>';   
}
if (reply == "ftp_failed") {
    document.getElementById("alerts").innerHTML = '<div class="panel panel-danger"><div class="panel-heading"><h3 class="panel-title text-center"><strong>FTP Password Reset: </strong> We are unable to reset the FTP Password as one or more nodes your servers are currently on look to be offline.</h3></div></div><br>';
}

// Show popups
function details() {
    $('#details').modal('show');
}

function change_jar() {
    $('#change_jar').modal('show');
}

function ftp_reset() {
    $('#ftp_password').modal('show');
}

// Toggle Switching for Console
function toggle_scrolling(){
  if(!scrolled){
    document.getElementById("scroll").innerHTML = "Unpause Console";
    scrolled = true;
  } else {
    document.getElementById("scroll").innerHTML = "Pause Console";
    scrolled = false;
  }
}

function scroller(){
    if(!scrolled){
      var objDiv = document.getElementById("logs");
      objDiv.scrollTop = objDiv.scrollHeight;
    }
setTimeout(scroller, 500);
}
scroller();

// Clear send command input.
function clearTextarea(){
    document.getElementById("command").value="";
}



// Console controls & checking.
function hasClass(element, cls) {
    return (' ' + element.className + ' ').indexOf(' ' + cls + ' ') > -1;
}

function control(type) {

var el = document.getElementById(type + '_button');
reply = hasClass(el, 'disabled');

if (reply == false) {
    
    document.getElementById("start_button").className = "btn btn-success disable disabled controls";
    document.getElementById("stop_button").className = "btn btn-danger disable disabled controls";
    document.getElementById("restart_button").className = "btn btn-warning disable disabled controls";
    document.getElementById("kill_button").className = "btn btn-info disable disabled controls";
    
    $.post(
      domain + '/controls/' + type + '/' + server_id,
      { action: type, "server_id": server_id, "secret": secret },
      function(data) {
          
         var data = jQuery.parseJSON(data);
        
        if (data.failed) { 
    
            document.getElementById("alerts").innerHTML = '<div class="panel panel-danger"><div class="panel-heading"><h3 class="panel-title text-center"><strong>Console Error: </strong> ' + data.failed + '</h3></div></div><br>';
    
        } else {
            
            document.getElementById("alerts").innerHTML = '';
            
        }
      }
    );

}

return false;
}


// GET Servers details.
function refresh(){
    
    $.getJSON(domain + "/get/" + server_id, function(json) {
        
        // If server is not suspended & license is active.
        if (suspended == "false" && json.license != "false") {
            
            document.getElementById("server-pid").innerHTML = json.server_pid;
            
            document.getElementById("cpu-text").innerHTML = json.cpu + "%";
            document.getElementById("memory-text").innerHTML = json.memory + "%";
            document.getElementById("disk-text").innerHTML = json.disk + "%";
            
            document.getElementById("cpu-value").style["width"] = json.cpu + "%";
            document.getElementById("memory-value").style["width"] = json.memory + "%";
            document.getElementById("disk-value").style["width"] = json.disk + "%";
            
            document.getElementById("players-online").innerHTML = json.players;
            
            document.getElementById("logs").innerHTML = json.console + "<br>";
            
            if (json.consolelines == "") { json.consolelines = 0; }
            document.getElementById("console-lines").innerHTML = json.consolelines;
            document.getElementById("node-status").innerHTML = json.nodestatus;
            document.getElementById("console-delay").innerHTML = json.consoledelay + "ms";
            document.getElementById("console-jar").innerHTML = json.jar;
          
        } else {
            
            document.getElementById("cpu-text").innerHTML = "0%";
            document.getElementById("memory-text").innerHTML = "0%";
            document.getElementById("disk-text").innerHTML = "0%";
            
            document.getElementById("cpu-value").style["width"] = "0%";
            document.getElementById("memory-value").style["width"] = "0%";
            document.getElementById("disk-value").style["width"] = "0%";
            
            document.getElementById("players-online").innerHTML = "0/0";
            
            document.getElementById("logs").innerHTML = json.console + "<br>";
            document.getElementById("console-lines").innerHTML = json.consolelines;
            document.getElementById("node-status").innerHTML = json.nodestatus;
            document.getElementById("console-delay").innerHTML = json.consoledelay + "ms";
            document.getElementById("console-jar").innerHTML = json.jar;
        
        }
        
        // If the node is online.
        if (json.nodestatus == "Online") {
            document.getElementById("node-status").className = "pull-right text-success";
        } else {
            document.getElementById("node-status").className = "pull-right text-danger";
        }
        
        
        // Server Status
        if (json.cpu <= 49) {
            document.getElementById("cpu-value").className = "progress-bar progress-bar-primary";
        } else if (json.cpu <= 74 && json.cpu >= 50) {
            document.getElementById("cpu-value").className = "progress-bar progress-bar-warning";
        } else {
            document.getElementById("cpu-value").className = "progress-bar progress-bar-danger";
        }
        
        if (json.memory <= 49) {
            document.getElementById("memory-value").className = "progress-bar progress-bar-primary";
        } else if (json.memory <= 74 && json.memory >= 50) {
            document.getElementById("memory-value").className = "progress-bar progress-bar-warning";
        } else {
            document.getElementById("memory-value").className = "progress-bar progress-bar-danger";
        }
        
        if (json.disk <= 49) {
            document.getElementById("disk-value").className = "progress-bar progress-bar-primary";
        } else if (json.disk <= 74 && json.disk >= 50) {
            document.getElementById("disk-value").className = "progress-bar progress-bar-warning";
        } else {
            document.getElementById("disk-value").className = "progress-bar progress-bar-danger";
        }
        
        // If the server is using BUNGEE
        if (json.bungee == "true") { 
            document.getElementById("bungee").innerHTML = server_id + " /-/ " + server_name + " (BUNGEE)";
        }
        
        // Check if the EULA needs accepting.
        if (json.eula == "true" && eula_check == "false") {
                
                eula_check = "true";
                console.log('Eula Setting: ' + eula_type);
                
            if (eula_type == "manual") {
                
                console.log('EULA Popup Activated!');
                $('#eula').modal('show');
                
            } else {
                
                console.log('EULA Auto Accepted');
                $.post(
                  domain + "/eula/" + server_id,
                  { eula: "true", "session": secret },
                  function(data) {
                    console.log(data);
                  }
                );
            
            } 
        }
        
        // Updating console based on scroll.
        if(!scrolled){
            if (suspended == "false") {
                document.getElementById("logs").innerHTML = json.console + "<br>";
            } else {
                document.getElementById("logs").innerHTML = '<div class="page-header text-center"><br><br><div class="page-title"><span class="font-weight-100">Server Suspended!</span></div><br><br></div>';
            } 
        }
        
        // Server Suspended.
        if (suspended == "true") {
            document.getElementById("server-status").innerHTML = "SERVER SUSPENDED";
            document.getElementById("server-status").className = "btn btn-lg btn-warning btn-block padding-17";
            
            document.getElementById("start_button").className = "btn btn-success disable disabled";
            document.getElementById("stop_button").className = "btn btn-danger disable disabled";
            document.getElementById("restart_button").className = "btn btn-warning disable disabled";
            
        } else {
            
            // Server Status Updating
            if (json.nodestatus == "Offline") {
                
                document.getElementById("server-status").innerHTML = "NODE OFFLINE";
                document.getElementById("server-status").className = "btn btn-lg btn-warning btn-block padding-17";
                
                document.getElementById("start_button").className = "btn btn-success disable disabled controls";
                document.getElementById("stop_button").className = "btn btn-danger disable disabled controls";
                document.getElementById("restart_button").className = "btn btn-warning disable disabled controls";
                document.getElementById("kill_button").className = "btn btn-info controls";
                
                document.getElementById("console_button").innerHTML = "<i class='fa fa-spinner fa-spin'></i> Send Command";
                document.getElementById("console_button").className = "btn btn-default disable disabled";
                    
            } else {
                
                document.getElementById("console_button").innerHTML = "<i class='fa fa-id-card'></i> Send Command";
                document.getElementById("console_button").className = "btn btn-default";
                
                if (json.status == "RUNNING") {
                    
                    document.getElementById("server-status").innerHTML = "SERVER ONLINE";
                    document.getElementById("server-status").className = "btn btn-lg btn-success btn-block padding-17";
                    
                    document.getElementById("start_button").className = "btn btn-success disable disabled controls";
                    document.getElementById("stop_button").className = "btn btn-danger controls";
                    document.getElementById("restart_button").className = "btn btn-warning controls";
                    document.getElementById("kill_button").className = "btn btn-info controls";
                    
                } else if (json.status == "INSTALLING") {
                    
                    document.getElementById("server-status").innerHTML = "SERVER INSTALLING";
                    document.getElementById("server-status").className = "btn btn-lg btn-primary btn-block padding-17";
                    
                    document.getElementById("start_button").className = "btn btn-success disable disabled controls";
                    document.getElementById("stop_button").className = "btn btn-danger disable disabled controls";
                    document.getElementById("restart_button").className = "btn btn-warning disable disabled controls";
                    document.getElementById("kill_button").className = "btn btn-info controls";
                    
                } else {
                    
                    document.getElementById("server-status").innerHTML = "SERVER OFFLINE";
                    document.getElementById("server-status").className = "btn btn-lg btn-danger btn-block padding-17";
                    
                    document.getElementById("start_button").className = "btn btn-success controls";
                    document.getElementById("stop_button").className = "btn btn-danger disable disabled controls";
                    document.getElementById("restart_button").className = "btn btn-warning disable disabled controls";
                    document.getElementById("kill_button").className = "btn btn-info controls";
                    
                } 
            }
        }
        
        
        // License Error
        if (json.license == "false") {
            
                document.getElementById("server-status").innerHTML = "LICENSE ERROR";
                document.getElementById("server-status").className = "btn btn-lg btn-warning btn-block padding-17";
                document.getElementById("group_buttons").setAttribute("style", "display: none;");
                document.getElementById("console_button").innerHTML = "<i class='fa fa-id-card'></i> Send Command";
                document.getElementById("console_button").className = "btn btn-default disable disabled";
                document.getElementById("logs").innerHTML = "";
        }
        
        
        // XenoDebug Checking
        if (json.debug != "false" && suspended == "false") {
            document.getElementById("debug").innerHTML = '<div class="panel panel-danger"><div class="panel-heading"><h3 class="panel-title"><strongConsole Error: </strong> ' + json.debug + '</h3></div></div><br>';
        } else {
            document.getElementById("debug").innerHTML = "";
            
            if (json.consoledelay > 10000) {
                document.getElementById("debug").innerHTML = '<div class="panel panel-warning"><div class="panel-heading"><h3 class="panel-title"><strong>Possible Issues: </strong> We have detected the delay from you to the node is over 5 seconds and may be affect you. The node may be experiencing issues.</h3></div></div><br>';
            }
        }
        
        if (json.license != "false") {
            document.getElementById("group_buttons").className = "";
        }
        
        setTimeout(refresh, refresh_delay);
    });
}
refresh();


// Console Send Command
function console_controls(form) {
    
    var submit = form.find("button[type='submit']");
    document.getElementById("console_button").innerHTML = "<i class='fa fa-spinner fa-spin'></i> Send Command";
    document.getElementById("console_button").className = "btn btn-default disable disabled";
    
    $.ajax({
      type: 'POST',
        url: form.attr("action"),
        data: form.serialize(),
        dataType: 'json',
        success: function(data)
        {
         console.log(data)
          if(data.success) {
              
            document.getElementById("console_button").innerHTML = "<i class='fa fa-id-card'></i> Send Command";
            document.getElementById("console_button").className = "btn btn-default";
            document.getElementById("debug-console").innerHTML = '';
            clearTextarea();
            
          } else {
              
            document.getElementById("console_button").innerHTML = "<i class='fa fa-id-card'></i> Command Error";
            document.getElementById("console_button").className = "btn btn-default";
    
          if (data.debug != "" && data.bug !== undefined) {
            document.getElementById("debug-console").innerHTML = '<div class="panel panel-danger"><div class="panel-heading"><h3 class="panel-title"><strongConsole Error: </strong> ' + data.debug + '</h3></div></div><br>';
          }
           
          }
    }
    });
    
    return false;
}