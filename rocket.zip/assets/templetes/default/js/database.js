function create_mysql(form){
    
    document.getElementById("connection").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-success disable disabled";
	var submit = form.find("button[type='submit']");
	$.ajax({
	  type: 'POST',
	    url: form.attr("action"),
	    data: form.serialize(),
	    dataType: 'json',
	    success: function(data)
	    {
        if (data.reply == "success") {
            document.getElementById("connection").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-success";
            document.getElementById("connection").value = 'Database Created! Refreshing...';
            setTimeout(function(){ location.reload();  }, 1000);
        }
        if (data.reply == "failed") {
            document.getElementById("connection").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-danger";
            document.getElementById("connection").value = 'Database Creating Failed!';
        }
	}
	});
return false;

} 

function delete_mysql(form){
    
    document.getElementById("connection").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-success disable disabled";
	var submit = form.find("button[type='submit']");
	$.ajax({
	  type: 'POST',
	    url: form.attr("action"),
	    data: form.serialize(),
	    dataType: 'json',
	    success: function(data)
	    {
	    if (data.reply == "success") {
            document.getElementById("connection").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-primary";
            document.getElementById("connection").value = 'Database Deleted! Refreshing...';
            setTimeout(function(){ location.reload();  }, 1000);
        }
        if (data.reply == "failed") {
            document.getElementById("connection").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-warning";
            document.getElementById("connection").value = 'Database Deleting Failed!';
        }
	}
	});
return false;

} 