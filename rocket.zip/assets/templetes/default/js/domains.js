function calc(type) {
    if (type == "up") {
        document.getElementById("available").innerHTML = parseInt(document.getElementById("available").innerHTML) - 1;
        document.getElementById("used").innerHTML = parseInt(document.getElementById("used").innerHTML) + 1;
    }
    if (type == "down") {
        document.getElementById("available").innerHTML = parseInt(document.getElementById("available").innerHTML) + 1;
        document.getElementById("used").innerHTML = parseInt(document.getElementById("used").innerHTML) - 1;
    }
    
    if (document.getElementById("used").innerHTML == "0") { document.getElementById('domain').innerHTML = none; }
}

function show_domain(domain) {
    
    if (document.getElementById('domain').innerHTML.indexOf("none-confirm") >= 0) {
        document.getElementById('domain').innerHTML = "";
    }
    
    document.getElementById('domain').innerHTML += '<div id="' + domain + '-main" class="panel panel-default margin-bottom-10"><div class="panel-heading"><h3 class="panel-title">Domain: ' + domain + '<span class="btn-group pull-right"></span></span></h3></div></div>';

}

function create_domain(form){
    
    document.getElementById("create-button").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-success disable disabled";
    document.getElementById("create-button").value = "Creating";
	var submit = form.find("button[type='submit']");
	$.ajax({
	  type: 'POST',
	    url: form.attr("action"),
	    data: form.serialize(),
	    dataType: 'json',
	    success: function(data)
	    {
        if (data.reply == "success") {

            document.getElementById("create-button").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-success";
            document.getElementById("create-button").value = "Created";
            document.getElementById("setdomain").value = "";
            show_domain(data.domain);
            calc('up');
            
        }
        if (data.reply == "failed") {
            document.getElementById("create-button").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-danger";
            document.getElementById("create-button").value = "Failed";
        }
	}
	});
return false;

} 


function load_domain() {
    
    $.ajax({
        url: domain + "/server_actions",
        data: {server_id: server_id, secret: secret, action: 'domain-list'},
        type: "POST",
        dataType: "json",
        success: function(data){
            
            document.getElementById('domain').innerHTML = '';
            reply = data.domains;
            
            if (reply == "none" || reply == "") { 
                document.getElementById('domain').innerHTML = none;
            } else {
            
            var output = reply.split(':');
            for(var i = 0; i < output.length; i++) {
               output[i] = output[i].replace(/^\s*/, "").replace(/\s*$/, "");
               show_domain(output[i]);
            }
            
            }
            
            
        }
    });
}
load_domain();