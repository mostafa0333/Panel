function sync(form){
    
    document.getElementById("create-button").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-success disable disabled";
    document.getElementById("create-button").value = "Attempting...";
	var submit = form.find("button[type='submit']");
	$.ajax({
	  type: 'POST',
	    url: form.attr("action"),
	    data: form.serialize(),
	    dataType: 'json',
	    success: function(data)
	    {
        if (data.reply == "success") {

            document.getElementById("create-button").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-success";
            document.getElementById("create-button").value = "Finishing Request...";
            setTimeout(function () { window.location.href= domain + '/fastdl/' + server_id; },1000);
            
        }
        
        if (data.reply == "failed") {
            document.getElementById("create-button").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-danger";
            document.getElementById("create-button").value = "Syncing Failed (You might already be in the queue)!";
        }
	}
	});
return false;

} 