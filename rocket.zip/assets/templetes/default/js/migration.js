function migrate(location){
    
    $.ajax({
        url: domain + "/server_actions",
        data: {server_id: server_id, secret: secret, action: 'migration-create', location: location},
        type: "POST",
        dataType: "json",
        success: function(data){
            if (data.reply == "success") {
                window.location.reload();
            } else {
                document.getElementById("alerts").innerHTML = '<div class="panel panel-danger"><div class="panel-heading"><h3 class="panel-title text-center"><strongConsole Error: </strong> Unable to migrate server. The server is either already in the queue or the addon is disabled.</h3></div></div><br>';
            }
        }
    });
}

function refresh(){
    
    $.ajax({
        url: domain + "/server_actions",
        data: {server_id: server_id, secret: secret, action: 'migration-status'},
        type: "POST",
        dataType: "json",
        success: function(data){
            
            console.log(data);
            
            if (data.status == "awaiting") {
                document.getElementById("status").innerHTML = "You're now in the queue! " + data.waiting + " others are also queued... <br><br> Once the migration beings you'll see details here.";
            }
            
            if (data.status == "selecting") {
                document.getElementById("status").innerHTML = "Migration Started! Attempting to pick a node...";
            }
            
            if (data.status == "connecting") {
                document.getElementById("status").innerHTML = "Node Selected! Checking Connection...";
            }
            
            if (data.status == "generating") {
                document.getElementById("status").innerHTML = "Node Connected! Generating new server configuration...";
                document.getElementById("status-button").className = "btn btn-primary hidden";
            }
            
            if (data.status == "transferring") {
                document.getElementById("status").innerHTML = "Configuration Set! Transferring the current server content...";
            }
            
            if (data.status == "updating") {
                document.getElementById("status").innerHTML = "Transfer Complete! Updating database with new server details...";
            }
            
            
            
            if (data.status == "complete") {
                document.getElementById("status").innerHTML = "Migration complete! The new server location is ready to be used!";
                document.getElementById("status-button").className = "btn btn-primary";
                document.getElementById("status-button").innerHTML = "View Console";
                document.getElementById("status-button").href = domain + "/overview/" + server_id + "/";
                document.getElementById("status-image").src = domain + "/assets/global/general/confirm.png";
                document.getElementById("status-image").style = "";
                
            }
            
            if (data.status == "failed") {
                document.getElementById("status").innerHTML = "Migration failed! Unable to find a node either online or with enough memory...";
                document.getElementById("status-button").className = "btn btn-danger";
                document.getElementById("status-button").innerHTML= "Remove Migration Request";
                document.getElementById("status-button").href = domain + "/migration/" + server_id + "/remove";
                document.getElementById("status-image").src = domain + "/assets/global/general/cancel.png";
                document.getElementById("status-image").style = "";
            }
            
            if (data.status == "failed-ip") {
                document.getElementById("status").innerHTML = "Migration failed! No dedicated IP available with selected node...";
                document.getElementById("status-button").className = "btn btn-danger";
                document.getElementById("status-button").innerHTML= "Remove Migration Request";
                document.getElementById("status-button").href = domain + "/migration/" + server_id + "/remove";
                document.getElementById("status-image").src = domain + "/assets/global/general/cancel.png";
                document.getElementById("status-image").style = "";
            }
            
        }
    });
    setTimeout(refresh, 500);
}
refresh();