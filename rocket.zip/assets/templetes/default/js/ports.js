function calc(type) {
    if (type == "up") {
        document.getElementById("available").innerHTML = parseInt(document.getElementById("available").innerHTML) - 1;
        document.getElementById("used").innerHTML = parseInt(document.getElementById("used").innerHTML) + 1;
    }
    if (type == "down") {
        document.getElementById("available").innerHTML = parseInt(document.getElementById("available").innerHTML) + 1;
        document.getElementById("used").innerHTML = parseInt(document.getElementById("used").innerHTML) - 1;
    }
    
    if (document.getElementById("used").innerHTML == "0") { document.getElementById('ports').innerHTML = none; }
}

function show_port(port) {
    
    if (document.getElementById('ports').innerHTML.indexOf("none-confirm") >= 0) {
        document.getElementById('ports').innerHTML = "";
    }
    
    document.getElementById('ports').innerHTML += '<div id="' + port + '-main" class="panel panel-default margin-bottom-10"><div class="panel-heading"><h3 class="panel-title">Port: ' + port + '<span class="btn-group pull-right"><a class="btn btn-danger btn-xs text-white margin-top-m8 margin-left-10" id="' + port + '" onclick="delete_port(this);">Delete Port</a></span></span></h3></div></div>';

}

function create_port(form){
    
    document.getElementById("create-button").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-success disable disabled";
    document.getElementById("create-button").value = "Creating Port...";
	var submit = form.find("button[type='submit']");
	$.ajax({
	  type: 'POST',
	    url: form.attr("action"),
	    data: form.serialize(),
	    dataType: 'json',
	    success: function(data)
	    {
        if (data.reply == "success") {

            document.getElementById("create-button").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-success";
            document.getElementById("create-button").value = "Extra Port Created!";
            show_port(data.port);
            calc('up');
            
        }
        if (data.reply == "failed") {
            document.getElementById("create-button").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-danger";
            document.getElementById("create-button").value = "Creating Failed!";
        }
	}
	});
return false;

} 

function delete_port(obj) {
    
    $.ajax({
        url: domain + "/server_actions",
        data: {server_id: server_id, secret: secret, action: 'port-delete', port: obj.id},
        type: "POST",
        dataType: "json",
        success: function(data){
            calc('down');
            document.getElementById("create-button").className = "btn btn-lg btn-block btn-rounded btn-shadow btn-primary";
            document.getElementById("create-button").value = "Create Extra Port";
            document.getElementById(obj.id + '-main').remove();
            
        }
    });

    return;
    
}


function load_ports() {
    
    $.ajax({
        url: domain + "/server_actions",
        data: {server_id: server_id, secret: secret, action: 'port-list'},
        type: "POST",
        dataType: "json",
        success: function(data){
            
            document.getElementById('ports').innerHTML = '';
            reply = data.ports;
            
            if (reply == "none" || reply == "") { 
                document.getElementById('ports').innerHTML = none;
            } else {
            
            var output = reply.split(':');
            for(var i = 0; i < output.length; i++) {
               output[i] = output[i].replace(/^\s*/, "").replace(/\s*$/, "");
               show_port(output[i]);
            }
            
            }
            
            
        }
    });
}
load_ports();