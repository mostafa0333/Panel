function toggle_button() {
    if (document.getElementById("create-button").className == "btn btn-primary btn-rounded btn-block") {
        document.getElementById("create-button").className = "hidden";
        document.getElementById("tasks").className = "hidden";
        document.getElementById("task-form").className = "";
    } else {
        document.getElementById("create-button").className = "btn btn-primary btn-rounded btn-block";
        document.getElementById("create-button").innerHTML = "Create Task";
        document.getElementById("task-form").className = "hidden";
    }
}

function check_connection(form){
    
    document.getElementById("check-connection").className = "btn btn-primary disable disabled";
    document.getElementById("check-connection").value = "Creating...";
	var submit = form.find("button[type='submit']");
	$.ajax({
	  type: 'POST',
	    url: form.attr("action"),
	    data: form.serialize(),
	    dataType: 'json',
	    success: function(data)
	    {
	     console.log(data)
        if (data.reply == "success") {
            document.getElementById("check-connection").className = "btn btn-success disable disabled";
            document.getElementById("check-connection").value = "Task Created!";
            setTimeout(function(){ window.location.replace(taskdomain); }, 1500);
        }
        if (data.reply == "failed") {
            document.getElementById("check-connection").className = "btn btn-primary";
            document.getElementById("check-connection").value = "Creating Failed!";
        }
	}
	});
return false;
} 

function enable_task(obj) {
    
    var id = obj.id;
    var nid = id.replace("-button", "");
    
    $.ajax({
        url: domain + "/server_actions",
        data: {server_id: server_id, secret: secret, action: 'task-enable', task: nid},
        type: "POST",
        dataType: "json",
        success: function(data){
            document.getElementById(obj.id).className = "btn btn-warning btn-xs";
            document.getElementById(obj.id).innerHTML = "Disable";
            document.getElementById(obj.id).setAttribute("onclick","disable_task(this)");
        
        }
    });

    return;
}


function disable_task(obj) {
    
    var id = obj.id;
    var nid = id.replace("-button", "");
    
    $.ajax({
        url: domain + "/server_actions",
        data: {server_id: server_id, secret: secret, action: 'task-disable', task: nid},
        type: "POST",
        dataType: "json",
        success: function(data){
            document.getElementById(obj.id).className = "btn btn-success btn-xs";
            document.getElementById(obj.id).innerHTML = "Enable";
            document.getElementById(obj.id).setAttribute("onclick","enable_task(this)");
        }
    });

    return;
}


function delete_task(obj) {
    
    var id = obj.id;
    var nid = id.replace("-delete", "");
    
    $.ajax({
        url: domain + "/server_actions",
        data: {server_id: server_id, secret: secret, action: 'task-delete', task: nid},
        type: "POST",
        dataType: "json",
        success: function(data){
            document.getElementById(obj.id).value = "Deleting...";
            document.getElementById(nid + '-main').remove();
        }
    });

    return;
}


function copy() {

    total = document.getElementById('total').value;
    total = parseInt(total) + 1;
    document.getElementById("total").value = total;

    if (total <= 25) {

    divReference = document.querySelector('.all_commands');
    var divToCreate = document.createElement('div');
    divReference.parentNode.appendChild(divToCreate);
    divToCreate.className = "commands";
    divToCreate.setAttribute("id", "commands_" + total);

    var templete_div = document.getElementById('templete');
    var secondDivContent = document.getElementById('mydiv2');

    command = document.getElementById('command');
    command.setAttribute("name", "command-" + total);
    command = document.getElementById('delete');
    command.setAttribute("onclick", "delete_commands(" + total + ");");

    divToCreate.innerHTML = templete_div.innerHTML;

  }
}

function delete_commands(command_id) {
    document.getElementById("commands_" + command_id).remove();
}